playSound("intro");

function startGame() {
    document.getElementById("startScreen").style.display = "none";
    startDogWalkout();
    // playSound("dogwalk");
}